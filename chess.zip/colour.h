#ifndef COLOUR_H
#define COLOUR_H

enum class Colour { Black, White };

#endif
